rootProject.name = "cap5lut-growbox"
includeBuild("../cap5lut-database")
