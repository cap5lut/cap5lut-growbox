package net.cap5lut.growbox.view.html.elements;

public class THEAD extends Element<THEAD> {
}
