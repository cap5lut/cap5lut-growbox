package net.cap5lut.growbox.view.html.elements;

public class H5 extends Element<H5> {
}
