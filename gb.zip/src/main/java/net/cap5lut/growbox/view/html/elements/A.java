package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithHref;
import net.cap5lut.growbox.view.html.attributes.WithTarget;

public class A extends Element<A> implements WithHref<A>, WithTarget<A> {
}
