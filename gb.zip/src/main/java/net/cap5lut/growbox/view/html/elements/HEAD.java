package net.cap5lut.growbox.view.html.elements;

public class HEAD extends Element<HEAD> {
}
