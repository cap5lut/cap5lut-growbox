package net.cap5lut.growbox.view.html.elements;

public class H6 extends Element<H6> {
}
