package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithHref;
import net.cap5lut.growbox.view.html.attributes.WithRel;

public class LINK extends Element<LINK> implements WithHref<LINK>, WithRel<LINK> {
}
