package net.cap5lut.growbox.view.html.elements;

public class TBODY extends Element<TBODY> {
}
