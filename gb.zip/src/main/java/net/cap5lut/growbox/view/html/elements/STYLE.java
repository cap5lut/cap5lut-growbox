package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithType;

public class STYLE extends Element<STYLE> implements WithType<STYLE> {
}
