package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithColspan;
import net.cap5lut.growbox.view.html.attributes.WithRowspan;

public class TH extends Element<TH> implements WithColspan<TH>, WithRowspan<TH> {
}
