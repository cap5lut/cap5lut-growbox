package net.cap5lut.growbox.view.html.elements;

public class UL extends Element<UL> {
}
