package net.cap5lut.growbox.view.html.elements;

public class ARTICLE extends Element<ARTICLE> {
}
