package net.cap5lut.growbox.view.html.elements;

public class TR extends Element<TR> {
}
