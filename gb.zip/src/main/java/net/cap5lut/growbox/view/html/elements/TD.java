package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithColspan;
import net.cap5lut.growbox.view.html.attributes.WithRowspan;

public class TD extends Element<TD> implements WithColspan<TD>, WithRowspan<TD> {
}
