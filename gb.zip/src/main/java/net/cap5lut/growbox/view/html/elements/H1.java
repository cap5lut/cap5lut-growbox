package net.cap5lut.growbox.view.html.elements;

public class H1 extends Element<H1> {
}
