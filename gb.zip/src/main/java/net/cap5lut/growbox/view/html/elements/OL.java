package net.cap5lut.growbox.view.html.elements;

public class OL extends Element<OL> {
}
