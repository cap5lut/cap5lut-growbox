package net.cap5lut.growbox.view.html.elements;

import net.cap5lut.growbox.view.html.attributes.WithSrc;
import net.cap5lut.growbox.view.html.attributes.WithType;

public class SCRIPT extends Element<SCRIPT> implements WithSrc<SCRIPT>, WithType<SCRIPT> {
}
