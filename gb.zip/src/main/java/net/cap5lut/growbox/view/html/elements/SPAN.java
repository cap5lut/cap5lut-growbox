package net.cap5lut.growbox.view.html.elements;

public class SPAN extends Element<SPAN> {
}
