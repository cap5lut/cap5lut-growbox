package net.cap5lut.growbox.view.html;

public abstract class Node {
    public abstract void toString(StringBuilder content);
    public abstract String toString();
}
