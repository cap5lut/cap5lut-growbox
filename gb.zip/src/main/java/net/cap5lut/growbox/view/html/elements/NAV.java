package net.cap5lut.growbox.view.html.elements;

public class NAV extends Element<NAV> {
}
