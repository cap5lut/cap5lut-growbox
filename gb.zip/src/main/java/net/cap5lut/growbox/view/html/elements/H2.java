package net.cap5lut.growbox.view.html.elements;

public class H2 extends Element<H2> {
}
