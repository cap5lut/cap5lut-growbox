package net.cap5lut.growbox.view.html.elements;

public class BODY extends Element<BODY> {
}
