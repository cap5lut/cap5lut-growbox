package net.cap5lut.growbox.view.html.elements;

public class TABLE extends Element<TABLE> {
}
