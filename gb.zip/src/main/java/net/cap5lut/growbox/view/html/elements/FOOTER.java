package net.cap5lut.growbox.view.html.elements;

public class FOOTER extends Element<FOOTER> {
}
