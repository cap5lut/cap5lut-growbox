<template id="growbox-overview">
  <article class="growbox-overview">
    <h1>Hello World</h1>
    <p>all devices</p>
  </article>
</template>
<script>
  app.component("growbox-overview", {template: "#growbox-overview"});
</script>
<style>
  article.growbox-overview {
    background-color: rgba(0, 0, 0, 0.1);
  }
</style>