SELECT device_id,
       name
FROM growbox.devices
WHERE device_id = ?;