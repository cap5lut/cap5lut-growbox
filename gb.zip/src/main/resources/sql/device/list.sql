SELECT device_id,
       name
FROM growbox.devices
ORDER BY device_id;