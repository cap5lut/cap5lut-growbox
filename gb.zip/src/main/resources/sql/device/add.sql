INSERT INTO growbox.devices (device_id, name)
VALUES (?, ?);